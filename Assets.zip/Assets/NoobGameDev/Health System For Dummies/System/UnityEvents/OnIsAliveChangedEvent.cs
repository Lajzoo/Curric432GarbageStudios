using System;
using UnityEditor;
using UnityEngine.Events;

[Serializable]
public class OnIsAliveChanged : UnityEvent<bool> { }
