using System;
using UnityEngine.Events;

[Serializable]
public class OnCurrentHealthChanged : UnityEvent<CurrentHealth> { }