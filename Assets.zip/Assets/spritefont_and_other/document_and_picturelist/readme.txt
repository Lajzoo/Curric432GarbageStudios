
Thanks for your download.


This asset is a pixel art set of font and other pixel art set for retro type 2D games. 
Each pixel art was drawn by only 4 colors.(sepia tone)  -like soft of old portable game-


This asset contains three pictures.(in "pics" folder)

fontsheet001.png------contains 10 types of sprite font.each size is 16x16 pixels and 8x8 pixels.
fontsheet002.png------contains 7 types of sprite font.each size is 16x16 pixels and 8x8 pixels.
other.png------contains some sprite for icons and for frame of window.


If you want to choose purpose sprite quickly,refer the "picturelist.png","picturelist2.png" or"picturelist3.png"
 (in "document_and_picturelist" folder). 



<caution>
Parency bug occurs in current version of unity when you use png image in [16bit] setting,so use png image in [true color] setting. 




