using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chicken : MonoBehaviour
{
    // Start is called before the first frame update
      Vector3 position;
      public Attack attackStatus;
     public float maxHealth = 100f;
    public float currentHealth;
    public HealthBar healthBar;
    public float Damage;
    bool move;
    // Start is called before the first frame update
    void Start()
    {
        position=transform.position;
          currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
    }

    // Update is called once per frame
    void Update()
    {
        if(attackStatus.AttackEnemy){
          StartCoroutine(AttackMove());
            }
       if(move){
        position.x-=0.002f*Mathf.Sin(2*Time.time);

        transform.position=position;
   }
      
    }
     IEnumerator AttackMove()
    {
       move=true;
            yield return new WaitForSeconds(2);
              
        move=false;
    }

}
