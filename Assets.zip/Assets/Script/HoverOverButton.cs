using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public class HoverOverButton : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public GameObject Arrow;
    public bool Hover;
    public bool beginBlink;
    float BlinkTime;
    // Start is called before the first frame update
    public void OnPointerEnter(PointerEventData eventData){
     Hover=true;
    }
    public void OnPointerExit(PointerEventData eventData){
      Arrow.SetActive(false);
      Hover=false;
    }

    IEnumerator Blink(){
        Arrow.SetActive(true);
        yield return new WaitForSeconds(0.2f);
          Arrow.SetActive(false);
    }
    public void Update(){
        BlinkTime+=Time.deltaTime;
        if(Hover){
            if(BlinkTime<0.5){

                 Arrow.SetActive(true);
            }
            else if(BlinkTime>0.5){
                
            Arrow.SetActive(false);
            }
         
        }
        if( BlinkTime>1){
            BlinkTime=0;
        }
    }
}
