using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Enemy : MonoBehaviour
{
    public float maxHealth = 100f;
    public float currentHealth;
    public HealthBar healthBar;
    public float Damage;
    public Chicken chicken;
    public Attack chickenAttack;
    bool hold;
    bool death;
    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
          
    }

    // Update is called once per frame
    void Update()
    {   
        if(currentHealth<=0){
              StartCoroutine(transition());
           
        }
        if(!hold&&!death){
        if(chickenAttack.AttackEnemy&&!hold){
            StartCoroutine(Attack());
           
        
        }
            GetComponent<EnemyMovement>().enabled=false;
        }
        if(hold){
         GetComponent<EnemyMovement>().enabled=true;
        }
        
    }

    IEnumerator Attack()

    {  
        hold=true;
        yield return new WaitForSeconds(2);
       
            yield return new WaitForSeconds(2);
              chicken.currentHealth -= Damage;
             chicken.healthBar.SetHealth(chicken.currentHealth);
        chickenAttack.AttackEnemy=false;
        hold=false;
    }
     IEnumerator transition()

    {  
       gameObject.GetComponent<Renderer>().enabled=false;
            death=true;
                yield return new WaitForSeconds(2);
              SceneManager.LoadScene(2);
    
       
            
    }
}
