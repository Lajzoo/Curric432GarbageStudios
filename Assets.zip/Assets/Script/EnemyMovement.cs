using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    Vector3 position;
    // Start is called before the first frame update
    void Start()
    {
        position=transform.position;
    }

    // Update is called once per frame
    void Update()
    {
       
        position.x+=0.002f*Mathf.Sin(2*Time.time);

        transform.position=position;
    }
}
