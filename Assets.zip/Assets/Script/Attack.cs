using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attack : MonoBehaviour
{
    public Enemy enemy;
    public bool AttackEnemy;
    // Start is called before the first frame update
    public void attack(){
        if(!AttackEnemy){
    enemy.currentHealth -= enemy.Damage;
    enemy.healthBar.SetHealth(enemy.currentHealth);
      AttackEnemy=true;
    }
  
    }
   
}

